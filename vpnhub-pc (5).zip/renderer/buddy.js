'use strict';
const $ = (s) => document.querySelector(s);
const buddy = $('#buddy'), bubble = $('#bubble'), fx = $('#fx'), spr = $('#spr'), hand = $('#hand'), charEl = $('#char');
const api = window.buddyApi;

// ---- картинки: у каждой позы есть кадры моргания (_b) и шевеления ушками (_e1a/_e1b/_e2a/_e2b) ----
const SPRITES = {
  sit: { h: 270, b: 1, e: [1, 2] }, tea: { h: 270, b: 1, e: [1, 2] }, mask: { h: 190, b: 1, e: [1, 2] },
  cs: { h: 270, b: 1, e: [] }, music: { h: 270, b: 0, e: [] }, shy: { h: 270, b: 0, e: [] }
};
const ASPECT = { sit: 0.823, tea: 0.938, mask: 1.05, cs: 0.854, music: 0.906, shy: 0.84 };   // ширина / высота картинок
Object.keys(SPRITES).forEach((k) => {
  const v = SPRITES[k]; const files = [k];
  if (v.b) files.push(k + '_b');
  v.e.forEach((n) => files.push(`${k}_e${n}a`, `${k}_e${n}b`));
  files.forEach((f) => { const i = new Image(); i.src = `sprites/${f}.webp`; });
});

// рука для поглаживания и 9 кадров объятия (кадры кладём в DOM заранее и декодируем, чтобы не мигало)
{ const h = new Image(); h.src = 'sprites/hand.png'; }
const HUG_N = 9, hugStage = $('#hugstage'), hugImgs = [];
for (let i = 1; i <= HUG_N; i++) {
  const im = new Image(); im.alt = ''; im.draggable = false; im.src = `sprites/hug${i}.webp`;
  if (im.decode) im.decode().catch(() => {});
  hugStage.appendChild(im); hugImgs.push(im);
}
const showHug = (n) => hugImgs.forEach((im, k) => im.classList.toggle('on', k === n - 1));

// ---- фразы: под то, что ты делаешь ----
const SAY = {
  idle: ['привет, фембойчек! 💗', 'погладь меня 🥺', 'как твой впн? быстро?', 'UwU', 'я тут, если что 🐾', 'мурр~', 'хочешь, обниму? 🤗', 'не забудь попить водички 💧', 'я охраняю твой интернет 🛡️', 'ты сегодня молодец ✨'],
  tea: ['ооо, ютуб! я с чаем 🍵', 'плед, чай и видосики — идеал 💗', 'что смотрим? я уже устроился 🧣', 'осторожно, горячо ☕', 'включи что-нибудь уютное~', 'главное — без рекламы 😌', 'я пью чай, а ты смотришь, всё честно 🍵', 'досмотрим до конца? 🥺'],
  music: ['ооо, музыка! 🎵', 'мои ушки в восторге 🎧', 'тсс, я слушаю 🎶', 'качаю хвостом в такт 🎵', '♪ ля-ля-ля ♪', 'кто это играет? мне нравится 💗', 'добавь в избранное, а? 🥺', 'сделай погромче! …нет, не надо 🙈'],
  read: ['ой, а что это вы там пишете… 👀', 'я не подсматриваю! почти… 🫣', 'так, кто тебе пишет?? 👀', 'он(а) ответил(а)? 🥺', 'секреты — это мило, я никому 🤫', 'печатает… ой, это не я ✍️', 'не забудь ответить, это невежливо 💌'],
  shy: ['я не смотрю!! 🙈', 'ой-ой, что ты открыл!! 😳', 'я закрыл глазки!! >///<', 'пожалуйста, закрой это 😖', 'я ничего не видел!! 🙈', 'мне стыдно… 🫣', 'эй, я же здесь!! 😳'],
  cs: ['цель на мушке! 🎯', 'держу сектор, не волнуйся 🔫', 'плент? нет, просто бегу 🏃', 'раунд будет наш! 💪', 'на B никого, честно 🫡', 'заряжаю… фембой на посту 🪖', 'хедшот? у меня лапки, но я стараюсь 🐾', 'дефьюз-кит не забыл? 💣'],
  mask: ['я ниндзя 🥷', 'тс-с, я в маске', 'get over here! 🦂', 'сзади буду незаметным…', 'мурр, но в маске 💜', 'они меня не видят 🥷'],
  pet: ['мурр~ 💗', 'ещё! 🥺', 'приятно…', 'мррр', 'хвост сам виляет 🐾']
};
const pick = (a) => a[Math.floor(Math.random() * a.length)];

// ---- состояние ----
let manual = 'sit', aware = '', mask = false, petting = false, petMove = 0, petTimer = null, heartTimer = null, bubbleTimer = null;
let lastHit = false, lastMeow = 0, lastSay = Date.now(), nextGap = 6000, current = '', cur = 'sit', animBusy = false, hgBusy = false;

const effective = () => aware || manual;
const spriteFor = (e) => ((e === 'tea' || e === 'music' || e === 'cs' || e === 'shy') ? e : (mask ? 'mask' : 'sit'));
const pool = (e) => ((e === 'sit' || e === 'lie') && mask ? SAY.mask : (SAY[e] || SAY.idle));

function say(t, ms) {
  bubble.textContent = t; bubble.classList.add('show'); lastSay = Date.now();
  clearTimeout(bubbleTimer); bubbleTimer = setTimeout(() => bubble.classList.remove('show'), ms || 3400);
}
function heart() {
  const h = document.createElement('span'); h.className = 'heart'; h.textContent = '❤';
  h.style.left = (60 + Math.random() * 190) + 'px'; fx.appendChild(h); setTimeout(() => h.remove(), 1300);
}

// ---- звуки (синтез, как у котика) ----
let actx = null, purrNode = null;
function audio() { if (!actx) { try { actx = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { return null; } } if (actx.state === 'suspended') actx.resume(); return actx; }
function meow() {
  const c = audio(); if (!c) return;
  const t = c.currentTime, pitch = 1.05 + Math.random() * 0.3, dur = 0.5 + Math.random() * 0.2;
  const osc = c.createOscillator(); osc.type = 'sawtooth';
  osc.frequency.setValueAtTime(460 * pitch, t); osc.frequency.linearRampToValueAtTime(860 * pitch, t + dur * 0.3); osc.frequency.linearRampToValueAtTime(600 * pitch, t + dur * 0.75); osc.frequency.linearRampToValueAtTime(420 * pitch, t + dur);
  const bp = c.createBiquadFilter(); bp.type = 'bandpass'; bp.Q.value = 2; bp.frequency.setValueAtTime(900, t); bp.frequency.linearRampToValueAtTime(2100, t + dur * 0.35); bp.frequency.linearRampToValueAtTime(1000, t + dur);
  const g = c.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.7, t + 0.06); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  osc.connect(bp); bp.connect(g); g.connect(c.destination); osc.start(t); osc.stop(t + dur + 0.05);
}
function purrStart() {
  const c = audio(); if (!c || purrNode) return;
  const len = c.sampleRate * 2, buf = c.createBuffer(1, len, c.sampleRate), d = buf.getChannelData(0); let last = 0;
  for (let i = 0; i < len; i++) { last = (last + 0.02 * (Math.random() * 2 - 1)) / 1.02; d[i] = last * 4; }
  const src = c.createBufferSource(); src.buffer = buf; src.loop = true;
  const lp = c.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 420;
  const am = c.createGain(); am.gain.value = 0.5; const lfo = c.createOscillator(); lfo.frequency.value = 25;
  const lg = c.createGain(); lg.gain.value = 0.5; lfo.connect(lg); lg.connect(am.gain);
  const master = c.createGain(); master.gain.setValueAtTime(0.0001, c.currentTime); master.gain.linearRampToValueAtTime(1, c.currentTime + 0.25);
  src.connect(lp); lp.connect(am); am.connect(master); master.connect(c.destination); src.start(); lfo.start(); purrNode = { src, lfo, master };
}
function purrStop() {
  if (!purrNode || !actx) return; const { src, lfo, master } = purrNode; purrNode = null; const t = actx.currentTime;
  master.gain.cancelScheduledValues(t); master.gain.setValueAtTime(master.gain.value, t); master.gain.linearRampToValueAtTime(0.0001, t + 0.3); src.stop(t + 0.35); lfo.stop(t + 0.35);
}

// ---- отрисовка позы ----
function render() {
  const e = effective(), k = spriteFor(e);
  buddy.className = e + (petting ? ' pet' : '') + (buddy.classList.contains('hover') ? ' hover' : '');
  if (k !== cur) { cur = k; spr.style.height = SPRITES[k].h + 'px'; spr.src = `sprites/${k}.webp`; }
  if (e === 'lie') $('.tilt').style.setProperty('--ly', '-' + (SPRITES[k].h * ASPECT[k] / 2 + 6) + 'px');   // лёжа кот занимает по высоте свою ширину
  if (e !== current) { current = e; if (!hgBusy) { say(pick(pool(e)), 4200); nextGap = 9000 + Math.random() * 5000; } }
}

// ---- моргание и шевеление ушками ----
function frame(k, suffix) { if (cur === k) spr.src = `sprites/${k}${suffix}.webp`; }
function blinkOnce() {
  const k = cur;
  if (animBusy || hgBusy || !SPRITES[k].b) return;
  animBusy = true; frame(k, '_b');
  setTimeout(() => { frame(k, ''); animBusy = false; }, 140);
}
function earOnce() {
  const k = cur, ears = SPRITES[k].e;
  if (animBusy || hgBusy || !ears.length) return;
  animBusy = true;
  const n = ears[Math.floor(Math.random() * ears.length)];
  const seq = [`_e${n}a`, `_e${n}b`, `_e${n}a`, `_e${n}b`, `_e${n}a`, ''];
  let i = 0;
  (function step() { frame(k, seq[i++]); if (i < seq.length && cur === k) setTimeout(step, 95); else animBusy = false; })();
}
(function loopBlink() { setTimeout(() => { blinkOnce(); loopBlink(); }, 2200 + Math.random() * 3200); })();
(function loopEar() { setTimeout(() => { earOnce(); loopEar(); }, 3500 + Math.random() * 4500); })();

// ---- фразы по ситуации: каждые 9–14 секунд, в покое реже ----
setInterval(() => {
  if (petting || hgBusy) return;
  if (Date.now() - lastSay > nextGap) {
    say(pick(pool(current || 'sit')), 3600);
    nextGap = (aware ? 9000 : 14000) + Math.random() * 6000;
  }
}, 1500);

// ---- поглаживание: курсор превращается в руку, которая гладит ----
function setPet(on) {
  if (on === petting) return;
  petting = on;
  if (on) { purrStart(); say(pick(SAY.pet), 2200); heart(); heartTimer = setInterval(heart, 420); }
  else { purrStop(); clearInterval(heartTimer); }
  render();
}

// ---- «Обнять экран» ----
function bigHeart() {
  const h = document.createElement('span'); h.className = 'bigheart'; h.textContent = '❤';
  h.style.left = (15 + Math.random() * 70) + 'vw'; h.style.top = (25 + Math.random() * 55) + 'vh'; document.body.appendChild(h); setTimeout(() => h.remove(), 1800);
}
function runBigHug() {
  if (hgBusy) return;
  hgBusy = true; setPet(false);
  let tries = 0;
  // главный процесс растягивает окно на весь экран асинхронно: ждём, пока размер окна станет размером экрана (не дольше ~0,6 с)
  const go = () => { if (window.innerWidth < screen.width - 4 && tries++ < 20) { setTimeout(go, 30); return; } playHug(); };
  go();
}
function playHug() {
  const b = document.body, T = (f, ms) => setTimeout(f, ms), st = hugStage.style;
  // кадр 439×390 растягиваем так, чтобы он накрывал экран; в конце лапки и мордочка заполняют весь экран
  const vw = window.innerWidth, vh = window.innerHeight, s = Math.max(vw / 439, vh / 390), W = 439 * s, H = 390 * s;
  st.width = W + 'px'; st.height = H + 'px'; st.left = ((vw - W) / 2) + 'px'; st.top = ((vh - H) / 2) + 'px';
  // старт: маленький кот в правом нижнем углу, там же, где сидел
  const k0 = Math.min(0.5, 300 / H);
  const small = `translate(${vw / 2 - 175}px, ${vh / 2 + 2 - k0 * H / 2}px) scale(${k0})`;
  st.transition = 'none'; st.transform = small; st.opacity = '0'; showHug(1);
  b.classList.add('bighug');
  void hugStage.offsetWidth;
  // вперёд: кадры 1→9, камера «подъезжает» к экрану
  T(() => { st.transition = 'transform 1.5s cubic-bezier(.35,.05,.25,1), opacity .25s'; st.opacity = '1'; st.transform = 'translate(0px, 0px) scale(1)'; }, 60);
  for (let n = 2; n <= HUG_N; n++) T(() => showHug(n), 60 + (n - 1) * 230);
  let hs = null;
  T(() => { hs = setInterval(bigHeart, 260); }, 1500);
  T(() => clearInterval(hs), 3700);
  // назад: кадры 9→1, кот уезжает на своё место
  T(() => {
    st.transition = 'transform 1.1s cubic-bezier(.5,0,.3,1)'; st.transform = small;
    for (let n = HUG_N - 1; n >= 1; n--) T(() => showHug(n), (HUG_N - n) * 120);
  }, 3800);
  T(() => { st.transition = 'opacity .25s'; st.opacity = '0'; }, 4900);
  T(() => { b.classList.remove('bighug'); hgBusy = false; if (api) api.call('bighugEnd'); say('спасибо, что обнял экран вместе со мной 💗', 3200); }, 5250);
}

// ---- события от главного процесса ----
if (api) api.onEvent((d) => {
  if (d.t === 'mode') { aware = d.v || ''; render(); }
  else if (d.t === 'cfg') { mask = !!d.mask; render(); }
  else if (d.t === 'bighug') { if (d.on) runBigHug(); }
  else if (d.t === 'cursor') {
    if (current === 'sit' && !petting && !hgBusy) $('.look').style.setProperty('--look', Math.max(-9, Math.min(9, (d.x - 160) / 40)) + 'deg');
  }
});

// ---- мышь: прозрачные места пропускают клики, на персонаже и меню — ловим ----
document.addEventListener('mousemove', (e) => {
  if (hgBusy) return;
  const el = document.elementFromPoint(e.clientX, e.clientY);
  const hit = !!(el && el.closest && el.closest('.hit'));
  if (hit !== lastHit) { lastHit = hit; buddy.classList.toggle('hover', hit); if (api) api.call('interactive', hit); }
  if (el && el.closest && el.closest('#char')) {
    petMove += Math.abs(e.movementX) + Math.abs(e.movementY);
    if (petMove > 140) setPet(true);
    if (petting) {
      const r = charEl.getBoundingClientRect();
      hand.style.left = (e.clientX - r.left) + 'px'; hand.style.top = (e.clientY - r.top) + 'px';
      clearTimeout(petTimer); petTimer = setTimeout(() => setPet(false), 700);
    }
  }
});
document.addEventListener('mouseleave', () => { setPet(false); lastHit = false; buddy.classList.remove('hover'); if (api) api.call('interactive', false); });
setInterval(() => { petMove = Math.max(0, petMove - 30); }, 200);
charEl.addEventListener('click', () => { heart(); const n = Date.now(); if (n - lastMeow > 450) { lastMeow = n; meow(); } say(pick(['мяу!', 'мур?', 'мрр 💗', '🐾', 'ой! щекотно~']), 1600); });
$('#menu').addEventListener('click', (e) => {
  const b = e.target.closest('button'); if (!b) return;
  const c = b.dataset.c;
  if (c === 'sit' || c === 'lie') { manual = c; render(); }
  else if (c === 'hug') { if (api) api.call('bighug'); }
  else if (c === 'bye') { say('пока-пока 👋', 800); setTimeout(() => api && api.call('close'), 600); }
});
render();
setTimeout(() => say(pick(SAY.idle), 3500), 700);
