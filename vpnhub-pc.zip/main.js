'use strict';
const { app, BrowserWindow, ipcMain, dialog, Tray, Menu, nativeImage, screen, desktopCapturer } = require('electron');
const path = require('path');
const fs = require('fs');
const net = require('net');
const dns = require('dns').promises;
const { spawn, spawnSync, execFile } = require('child_process');
const { pathToFileURL } = require('url');
const Parser = require('./lib/parser');
const Sub = require('./lib/subscription');
const Cfg = require('./lib/config');
const { Store, defaultUi } = require('./lib/store');
const BuddyLib = require('./lib/buddy');
const Updater = require('./lib/updater');
let buddy = null;

let BUILD_ID = 'dev', BUILD_REPO = '';
try { const b = require('./build-id.json'); BUILD_ID = b.id || 'dev'; BUILD_REPO = b.repo || ''; } catch (e) { /* запуск из исходников */ }
Updater.setRepo(BUILD_REPO);
const FULL_VERSION = app.getVersion() + '+' + BUILD_ID;   // уникальна для каждой сборки

// ---- журнал запуска: если программа вдруг закрылась или пропала, причина будет в файле %APPDATA%\VPN Hub\startup.log ----
const LOG_FILE = path.join(app.getPath('userData'), 'startup.log');
function dlog(m) {
  try { fs.mkdirSync(path.dirname(LOG_FILE), { recursive: true }); fs.appendFileSync(LOG_FILE, new Date().toISOString() + ' [' + process.pid + '] ' + m + '\n'); } catch (e) { /* ignore */ }
}
try { if (fs.existsSync(LOG_FILE) && fs.statSync(LOG_FILE).size > 200000) fs.writeFileSync(LOG_FILE, ''); } catch (e) { /* ignore */ }
dlog(`START ${FULL_VERSION} exec=${process.execPath} portable=${process.env.PORTABLE_EXECUTABLE_FILE || '-'} args=${process.argv.slice(1).join(' ')}`);
process.on('uncaughtException', (e) => { dlog('UNCAUGHT ' + ((e && e.stack) || e)); try { if (app.isReady()) dialog.showErrorBox('VPN Hub', String((e && e.message) || e)); } catch (x) { /* ignore */ } });
process.on('unhandledRejection', (e) => dlog('UNHANDLED ' + ((e && e.stack) || e)));
process.on('exit', (c) => dlog('EXIT ' + c));
let upd = { available: null, status: '', busy: false };
let S, win = null, tray = null, proc = null;
let vpn = { state: 'off', error: '' };
let logLines = [];
let quitting = false;
let restartTimer = null;
let busy = false;
let lastTrayState = '';
let startTimer = null;
let clash = null, nowTimer = null;

const ansi = /\x1b\[[0-9;]*m/g;
const clean = (s) => String(s).replace(ansi, '').trim();
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const coreExe = () => (app.isPackaged ? path.join(process.resourcesPath, 'core', 'vpnhub-core.exe') : path.join(__dirname, 'core', 'vpnhub-core.exe'));
const isWin = process.platform === 'win32';

function isAdmin() {
  if (!isWin) return true;
  try { return spawnSync('net', ['session'], { windowsHide: true }).status === 0; } catch (e) { return false; }
}
function killStray() {
  if (!isWin) return;
  try { spawnSync('taskkill', ['/F', '/T', '/IM', 'vpnhub-core.exe'], { windowsHide: true }); } catch (e) { /* нет процесса */ }
}

// ---------- состояние для окна ----------
function publicState() {
  const ui = Object.assign({}, S.d.ui);
  ui.bgUrl = '';
  if (ui.bgKind === 'image' && ui.bgFile) {
    const f = path.join(app.getPath('userData'), ui.bgFile);
    if (fs.existsSync(f)) ui.bgUrl = pathToFileURL(f).href + '?v=' + ui.bgVer;
  }
  return {
    vpn, busy, ui, version: FULL_VERSION, update: upd,
    servers: S.servers.map((s) => { const i = S.info(s); return { id: s.id, subId: s.subId, name: s.name, kind: i.kind, clean: i.clean, gkey: i.gkey, isUdp: i.isUdp }; }),
    subs: S.d.subs, subInfo: S.subInfo, selected: S.d.selected, describe: S.describe(S.d.selected),
    rules: S.d.rules, pings: S.pings, buddy: !!(buddy && buddy.isOpen()),
    opts: { ruDirect: S.d.ruDirect, blockQuic: S.d.blockQuic, preferTcp: S.d.preferTcp, blockIpv6: S.d.blockIpv6, sni: S.d.sni }
  };
}
function push() {
  if (win && !win.isDestroyed()) win.webContents.send('state', publicState());
  updateTray();
}
function changed() { push(); scheduleRestart(); }


function freePort() {
  return new Promise((resolve) => {
    const srv = net.createServer();
    srv.once('error', () => resolve(0));
    srv.listen(0, '127.0.0.1', () => { const p = srv.address().port; srv.close(() => resolve(p)); });
  });
}
/** Какой сервер сейчас реально используется (для «Авто» и групп). */
async function pollNow() {
  if (!clash || !clash.port || vpn.state !== 'on') return;
  let text = '';
  try {
    const r = await fetch(`http://127.0.0.1:${clash.port}/proxies/main`, { headers: { Authorization: 'Bearer ' + clash.secret }, signal: AbortSignal.timeout(2500) });
    if (r.ok) {
      const j = await r.json();
      const tag = String(j.now || '');
      const id = tag.startsWith('s-') ? tag.slice(2).split('-')[0] : '';
      const sv = S.servers.find((x) => x.id === id);
      if (sv) { const i = S.info(sv); text = `${i.clean} · ${i.kind}`; }
    }
  } catch (e) { /* ядро ещё поднимается */ }
  if (text !== (vpn.now || '')) { vpn = Object.assign({}, vpn, { now: text }); push(); }
}

// ---------- ядро sing-box ----------
async function startVpn() {
  if (vpn.state !== 'off') return;
  vpn = { state: 'starting', error: '' };
  push();
  try {
    if (!isAdmin()) throw new Error('Нужны права администратора. Закрой программу и запусти её от имени администратора.');
    if (!fs.existsSync(coreExe())) throw new Error('Не найдено ядро sing-box (' + coreExe() + ')');
    killStray();
    const clashPort = await freePort();
    const secret = require('crypto').randomBytes(8).toString('hex');
    clash = { port: clashPort, secret };
    const cfgText = Cfg.build(S, { clashPort, secret });
    const dir = path.join(app.getPath('userData'), 'work');
    fs.mkdirSync(dir, { recursive: true });
    const cfgPath = path.join(dir, 'config.json');
    fs.writeFileSync(cfgPath, cfgText);
    const chk = spawnSync(coreExe(), ['check', '-c', cfgPath, '-D', dir], { windowsHide: true, encoding: 'utf8' });
    if (chk.error) throw new Error('Не удалось запустить ядро: ' + chk.error.message);
    if (chk.status !== 0) throw new Error('Ошибка конфигурации: ' + clean(chk.stderr || chk.stdout || '').slice(0, 700));

    logLines = [];
    const p = spawn(coreExe(), ['run', '-c', cfgPath, '-D', dir], { windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
    proc = p;
    const onData = (buf) => {
      for (const raw of buf.toString('utf8').split(/\r?\n/)) {
        const l = clean(raw);
        if (!l) continue;
        logLines.push(l);
        if (logLines.length > 600) logLines.shift();
        if (/sing-box started/i.test(l)) markOn();
      }
    };
    p.stdout.on('data', onData);
    p.stderr.on('data', onData);
    p.on('error', (err) => { vpn = { state: 'off', error: 'Не удалось запустить ядро: ' + err.message }; proc = null; push(); });
    p.on('exit', (code) => {
      clearTimeout(startTimer); clearInterval(nowTimer);
      const wasStopping = vpn.state === 'stopping';
      if (proc === p) proc = null;
      if (wasStopping || vpn.state === 'off') vpn = { state: 'off', error: vpn.error || '' };
      else {
        const tail = logLines.filter((l) => /ERROR|FATAL/i.test(l)).slice(-3).join('\n');
        const hint = /already exists|уже существует/i.test(tail) ? '\nСкорее всего, адаптер занят другой программой. Закрой другие VPN-клиенты (Happ, v2rayN, Hiddify, Nekoray…) и нажми подключить ещё раз.' : '';
        vpn = { state: 'off', error: 'Ядро остановилось (код ' + code + ')' + (tail ? ':\n' + tail : '') + hint };
      }
      push();
    });
    // запасной вариант, если строка «started» не появилась
    startTimer = setTimeout(() => { if (proc === p && vpn.state === 'starting') markOn(); }, 8000);
  } catch (e) {
    vpn = { state: 'off', error: String(e.message || e) };
    push();
  }
}
function markOn() {
  if (vpn.state === 'starting') {
    vpn = { state: 'on', error: '', now: '' }; push();
    clearInterval(nowTimer); nowTimer = setInterval(pollNow, 5000); setTimeout(pollNow, 1500);
  }
}
function stopVpn() {
  return new Promise((resolve) => {
    clearTimeout(startTimer); clearInterval(nowTimer);
    if (!proc) { vpn = { state: 'off', error: '' }; push(); return resolve(); }
    const p = proc;
    vpn = { state: 'stopping', error: '' };
    push();
    let done = false;
    const fin = () => { if (!done) { done = true; resolve(); } };
    p.once('exit', fin);
    try { p.kill(); } catch (e) { /* ignore */ }
    setTimeout(() => { if (proc === p) { try { spawnSync('taskkill', ['/F', '/T', '/PID', String(p.pid)], { windowsHide: true }); } catch (e) { /* ignore */ } } }, 2500);
    setTimeout(() => { if (!done) { proc = null; vpn = { state: 'off', error: '' }; push(); fin(); } }, 5000);
  });
}
function scheduleRestart() {
  clearTimeout(restartTimer);
  if (vpn.state !== 'on') return;
  restartTimer = setTimeout(async () => {
    if (vpn.state !== 'on') return;
    await stopVpn(); await sleep(600); await startVpn();
  }, 1500);
}

// ---------- подписки ----------
function hwid() {
  if (!S.d.hwid) S.d.hwid = require('crypto').randomBytes(8).toString('hex');
  return S.d.hwid;
}
async function fetchText(url, ua) {
  const res = await fetch(url, {
    headers: { 'User-Agent': ua, Accept: '*/*', 'x-hwid': hwid(), 'x-device-os': 'Windows', 'x-device-model': 'PC', 'x-ver-os': '10' },
    redirect: 'follow', signal: AbortSignal.timeout(25000)
  });
  if (!res.ok) throw new Error('HTTP ' + res.status);
  const body = await res.text();
  let title = res.headers.get('profile-title');
  if (title && title.startsWith('base64:')) title = Buffer.from(title.slice(7), 'base64').toString('utf8');
  return { body, title: title ? title.trim() : null };
}
const mask = (s) => s.replace(/[A-Za-z0-9+\/=_-]{20,}/g, (m) => m.slice(0, 6) + '…');
const usable = (r) => r.links.reduce((a, l) => a + Parser.outbounds({ id: 'x', name: 'x', link: l }, 't').filter((o) => o.type !== 'urltest').length, 0);

async function loadSub(url) {
  let best = null, bestScore = -1, title = null, diag = '';
  for (const ua of ['Happ/2.7.0', 'sing-box/1.11.4', 'v2rayN/6.45']) {
    const tag = ua.split('/')[0];
    try {
      const f = await fetchText(url, ua);
      if (!title) title = f.title;
      const r = Sub.parse(f.body);
      const score = usable(r);
      diag += `${tag}: ответ ${f.body.length} симв., формат «${r.format}», записей ${r.links.length}, рабочих ключей ${score}\n`;
      if (!r.links.length) diag += `  начало: «${mask(f.body.trim().slice(0, 90))}»\n`;
      if (score > bestScore) { best = r; bestScore = score; }
    } catch (e) { diag += `${tag}: ошибка ${e.message || e}\n`; }
  }
  return { result: best, title, diag: diag.trim() };
}

function extractSubUrl(t) {
  const s = t.trim(); const l = s.toLowerCase();
  if (l.startsWith('http://') || l.startsWith('https://')) return s;
  const prefixes = ['happ://add/', 'hiddify://import/', 'sing-box://import-remote-profile?url=', 'v2rayng://install-sub?url=', 'v2box://install-sub?url=',
    'clash://install-config?url=', 'clashmeta://install-config?url=', 'streisand://import/'];
  for (const p of prefixes) if (l.startsWith(p)) return Parser.dec(s.slice(p.length)).split('#')[0];
  return null;
}

async function refreshSub(sub) {
  busy = true; push();
  try {
    const l = await loadSub(sub.url);
    if (!l.result || !l.result.links.length) { S.subInfo[sub.id] = l.diag; return 'Серверы не найдены — подробности под названием подписки'; }
    delete S.subInfo[sub.id];
    S.replaceSub(sub.id, l.result.links);
    if (l.title) { const x = S.d.subs.find((z) => z.id === sub.id); if (x) x.name = l.title; S.save(); }
    return `Загружено подключений: ${l.result.links.length} (${l.result.format})`;
  } finally { busy = false; push(); }
}

// ---------- проверки ----------
function tcpPing(host, port, timeout) {
  return new Promise((resolve) => {
    const t0 = Date.now();
    const sock = net.connect({ host, port });
    const fin = (v) => { sock.destroy(); resolve(v); };
    sock.setTimeout(timeout, () => fin(-1));
    sock.once('connect', () => fin(Date.now() - t0));
    sock.once('error', () => fin(-1));
  });
}
async function pingAll() {
  if (vpn.state !== 'off') return 'Пинг показывает правду только при выключенном VPN — отключись и повтори';
  const list = S.servers.filter((s) => !S.info(s).isUdp);
  let idx = 0;
  const worker = async () => {
    while (idx < list.length) {
      const s = list[idx++];
      const hp = Parser.hostPort(s.link);
      if (!hp) continue;
      S.pings[s.id] = await tcpPing(hp.host, hp.port, 3000);
      push();
    }
  };
  await Promise.all(Array.from({ length: 8 }, worker));
  return null;
}
async function testNet() {
  const out = [];
  try { const t = Date.now(); const a = await dns.lookup('www.gstatic.com'); out.push(`1) DNS: ${a.address} (${Date.now() - t} мс)`); } catch (e) { out.push('1) DNS: ОШИБКА ' + (e.code || e.message)); }
  const t1 = await tcpPing('1.1.1.1', 443, 4000);
  out.push(t1 >= 0 ? `2) TCP до 1.1.1.1: ${t1} мс` : '2) TCP до 1.1.1.1: ОШИБКА');
  try {
    const t = Date.now();
    const r = await fetch('https://www.gstatic.com/generate_204', { signal: AbortSignal.timeout(8000) });
    out.push(`3) HTTPS: код ${r.status} (${Date.now() - t} мс)`);
  } catch (e) { out.push('3) HTTPS: ОШИБКА ' + (e.message || e)); }
  try {
    const t = Date.now();
    const r = await fetch('https://speed.cloudflare.com/__down?bytes=8000000', { signal: AbortSignal.timeout(30000) });
    const reader = r.body.getReader();
    let n = 0;
    for (;;) { const { done, value } = await reader.read(); if (done) break; n += value.length; }
    const sec = (Date.now() - t) / 1000;
    out.push(`4) Скорость: ${(n * 8 / 1e6 / sec).toFixed(1)} Мбит/с (${(n / 1e6).toFixed(1)} МБ за ${sec.toFixed(1)} с)`);
  } catch (e) { out.push('4) Скорость: ОШИБКА ' + (e.message || e)); }
  try {
    const r = await fetch('https://api.ipify.org', { signal: AbortSignal.timeout(8000) });
    out.push('5) Внешний IP: ' + (await r.text()).trim());
  } catch (e) { out.push('5) Внешний IP: ОШИБКА'); }
  return out.join('\n');
}
function listProcs() {
  return new Promise((resolve) => {
    if (!isWin) return resolve([]);
    execFile('tasklist', ['/fo', 'csv', '/nh'], { windowsHide: true, maxBuffer: 8 * 1024 * 1024 }, (err, stdout) => {
      if (err) return resolve([]);
      const skip = new Set(['system', 'registry', 'smss.exe', 'csrss.exe', 'wininit.exe', 'services.exe', 'lsass.exe', 'svchost.exe', 'fontdrvhost.exe', 'dwm.exe',
        'conhost.exe', 'vpnhub-core.exe', 'memory compression', 'secure system', 'system idle process', 'winlogon.exe', 'tasklist.exe', 'cmd.exe', 'wmiprvse.exe', 'sihost.exe', 'ctfmon.exe']);
      const names = new Set();
      for (const line of String(stdout).split(/\r?\n/)) {
        const m = /^"([^"]+)"/.exec(line);
        if (m && !skip.has(m[1].toLowerCase())) names.add(m[1]);
      }
      resolve([...names].sort((a, b) => a.toLowerCase().localeCompare(b.toLowerCase())));
    });
  });
}

// ---------- автообновление ----------
async function checkUpdate(manual) {
  if (upd.busy) return null;
  upd.busy = true;
  if (manual) { upd.status = 'Проверяю…'; push(); }
  try {
    const id = await Updater.latestId();
    const newer = Updater.isNewer(id, BUILD_ID);
    upd.available = newer ? id : null;
    upd.status = newer ? `Доступна новая сборка ${id} (у тебя ${BUILD_ID})` : `У тебя последняя версия (${BUILD_ID})`;
  } catch (e) { if (manual) upd.status = 'Не удалось проверить: ' + (e.message || e); }
  upd.busy = false;
  push();
  return upd.available;
}
async function applyUpdate() {
  if (upd.busy) return;
  upd.busy = true; upd.status = 'Скачиваю обновление…'; push();
  const dl = path.join(app.getPath('userData'), 'update', 'VPN-Hub-new.exe');
  try {
    await Updater.download(dl, (p) => { upd.status = 'Скачиваю обновление… ' + p + '%'; push(); });
    S.d.lastUpdateTry = upd.available; S.saveNow();
    const launch = Updater.swapExe(process.env.PORTABLE_EXECUTABLE_FILE, dl);
    upd.status = 'Перезапускаю…'; push();
    const child = spawn(launch, [], { detached: true, stdio: 'ignore' });
    let startErr = null;
    await new Promise((resolve) => { child.once('error', (e) => { startErr = e; resolve(); }); setTimeout(resolve, 900); });
    if (startErr) throw new Error('не удалось запустить новую версию: ' + startErr.message);
    child.unref();
    quitting = true; cleanup();
    setTimeout(() => app.exit(0), 300);
  } catch (e) { upd.busy = false; upd.status = 'Ошибка обновления: ' + (e.message || e); push(); }
}
function autoUpdateTick(startup) {
  if (!S.d.ui.autoUpdate) return;
  checkUpdate(false).then((id) => {
    if (!id) return;
    if (S.d.lastUpdateTry === id) { upd.status = `Сборка ${id} уже пробовала поставиться, но не вышло — обнови вручную`; push(); return; }
    if (startup || vpn.state === 'off') applyUpdate();
    else { upd.status = `Доступна сборка ${id} — нажми «Обновить сейчас», когда VPN можно отключить`; push(); }
  });
}

// ---------- иконка окна и трея ----------
function effectiveIcon() {
  const u = S.d.ui, m = u.iconMode || 'auto';
  if (m === 'fem' || m === 'mk' || m === 'default') return m;
  return u.femboy ? 'fem' : (u.scorpion ? 'mk' : 'default');
}
function applyIcon() {
  try {
    const img = nativeImage.createFromPath(path.join(__dirname, 'assets', `icon-${effectiveIcon()}.png`));
    if (img.isEmpty()) return;
    if (win && !win.isDestroyed()) win.setIcon(img);
    if (tray) tray.setImage(img.resize({ width: 32, height: 32 }));
  } catch (e) { /* иконка не критична */ }
}

// ---------- вызовы из окна ----------
const methods = {
  async toggle() { if (vpn.state === 'off') await startVpn(); else if (vpn.state === 'on' || vpn.state === 'starting') await stopVpn(); },
  select(t) { S.d.selected = t; S.save(); changed(); },
  async add(text) {
    text = String(text || '').trim();
    if (!text) return { msg: 'Пусто' };
    if (text.toLowerCase().startsWith('happ://crypt')) return { msg: 'Это зашифрованная ссылка Happ — такие не поддерживаются. Нужна обычная ссылка подписки (https://…)' };
    const url = extractSubUrl(text);
    if (url) {
      let host = 'Подписка'; try { host = new URL(url).host; } catch (e) { /* ignore */ }
      const sub = { id: S.idOf(url), name: host, url };
      if (!S.d.subs.some((x) => x.id === sub.id)) S.d.subs.push(sub);
      S.save();
      return { msg: await refreshSub(sub) };
    }
    const r = Sub.parse(text);
    const n = S.addLinks(r.links, null);
    push();
    return { msg: n > 0 ? 'Добавлено ключей: ' + n : 'Не удалось распознать. Вставь ключ (vless://…) или ссылку подписки (https://…)' };
  },
  async refreshSub(id) { const s = S.d.subs.find((x) => x.id === id); return s ? { msg: await refreshSub(s) } : null; },
  removeSub(id) { S.removeSub(id); push(); },
  removeGroup(key) { S.servers.filter((s) => S.info(s).gkey === key).map((s) => s.id).forEach((i) => S.removeServer(i)); changed(); },
  async pingAll() { const m = await pingAll(); return m ? { msg: m } : null; },
  setRule(procName, target) {
    procName = String(procName || '').trim();
    if (!procName) return;
    if (!target || target === 'default') delete S.d.rules[procName]; else S.d.rules[procName] = target;
    S.save(); changed();
  },
  async listProcs() { return await listProcs(); },
  setOpt(k, v) {
    if (k === 'ruDirect' || k === 'blockQuic' || k === 'preferTcp' || k === 'blockIpv6') S.d[k] = !!v;
    else if (k === 'sni') S.d.sni = String(v || '').trim();
    else return;
    S.save(); changed();
  },
  setUi(k, v) { if (k in S.d.ui) { S.d.ui[k] = v; S.save(); updateTray(true); if (k === 'buddyAware' && buddy && buddy.isOpen()) buddy.applyAware(); if (k === 'femboy' || k === 'scorpion' || k === 'iconMode') applyIcon(); } },
  async checkUpdate() { await checkUpdate(true); return null; },
  applyUpdate() { applyUpdate(); return null; },
  buddyToggle() {
    if (!buddy) return { msg: 'Бойкиссер недоступен' };
    const on = buddy.toggle();
    return { msg: on ? 'Бойкиссер пришёл! 💗 Наведи на него мышь: там команды, а погладить можно просто поводив курсором' : 'Бойкиссер ушёл спать 😴' };
  },
  resetUi() {
    try { if (S.d.ui.bgFile) fs.unlinkSync(path.join(app.getPath('userData'), S.d.ui.bgFile)); } catch (e) { /* ignore */ }
    const keep = S.d.ui.bgVer || 0;
    S.d.ui = Object.assign(defaultUi(), { bgVer: keep + 1 });
    S.save(); applyIcon(); push();
  },
  async pickBg() {
    const r = await dialog.showOpenDialog(win, { properties: ['openFile'], filters: [{ name: 'Изображения', extensions: ['jpg', 'jpeg', 'png', 'webp', 'bmp', 'gif'] }] });
    if (r.canceled || !r.filePaths.length) return null;
    const src = r.filePaths[0];
    const ext = path.extname(src).toLowerCase() || '.jpg';
    const name = 'background' + ext;
    try {
      if (S.d.ui.bgFile && S.d.ui.bgFile !== name) { try { fs.unlinkSync(path.join(app.getPath('userData'), S.d.ui.bgFile)); } catch (e) { /* ignore */ } }
      fs.copyFileSync(src, path.join(app.getPath('userData'), name));
    } catch (e) { return { msg: 'Не удалось скопировать картинку: ' + e.message }; }
    S.d.ui.bgFile = name; S.d.ui.bgKind = 'image'; S.d.ui.bgVer = (S.d.ui.bgVer || 0) + 1;
    S.save(); push();
    return null;
  },
  async testNet() { return await testNet(); },
  getLog() { return logLines.slice(-250).join('\n'); }
};
ipcMain.handle('call', async (_e, name, args) => {
  try { const f = methods[name]; if (!f) return { error: 'unknown ' + name }; return await f(...(args || [])); } catch (err) { return { error: String(err.message || err) }; }
});

// ---------- окно и трей ----------
function showWin() { if (!win) return; if (win.isMinimized()) win.restore(); win.show(); win.focus(); }
function updateTray(force) {
  if (!tray) return;
  const st = vpn.state;
  if (!force && st === lastTrayState) return;
  lastTrayState = st;
  const on = st === 'on';
  tray.setToolTip((S.d.ui.title || 'VPN Hub') + ' v' + app.getVersion() + ' — ' + (on ? 'подключено' : st === 'starting' ? 'подключение…' : 'отключено'));
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: 'Открыть', click: showWin },
    { label: on || st === 'starting' ? 'Отключить' : 'Подключить', click: () => methods.toggle() },
    { type: 'separator' },
    { label: 'Выход', click: () => { quitting = true; app.quit(); } }
  ]));
}
function createWindow() {
  win = new BrowserWindow({
    width: 480, height: 820, minWidth: 380, minHeight: 600, backgroundColor: '#0B0F1A', autoHideMenuBar: true, title: 'VPN Hub',
    icon: path.join(__dirname, 'assets', 'tray.png'),
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false }
  });
  win.setMenuBarVisibility(false);
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('did-finish-load', () => { dlog('window loaded'); push(); });
  win.webContents.on('did-fail-load', (_e, code, desc) => dlog('did-fail-load ' + code + ' ' + desc));
  win.webContents.on('render-process-gone', (_e, d) => dlog('render-process-gone ' + JSON.stringify(d)));
  win.on('close', (e) => { if (!quitting && S.d.ui.trayClose && tray) { e.preventDefault(); win.hide(); } });
  win.on('closed', () => { win = null; });
}
function cleanup() {
  quitting = true;
  try { if (buddy) buddy.cleanup(); } catch (e) { /* ignore */ }
  clearTimeout(restartTimer);
  if (proc) { try { spawnSync('taskkill', ['/F', '/T', '/PID', String(proc.pid)], { windowsHide: true }); } catch (e) { /* ignore */ } }
}

function boot() {
  // Если запущена НОВАЯ версия, старый экземпляр (часто спрятанный в трее) сам закрывается и уступает место.
  dlog('boot');
  app.on('second-instance', (_e, _argv, _cwd, data) => {
    dlog('second-instance, other version=' + (data && data.version));
    if (data && data.version && data.version !== FULL_VERSION) { dlog('другая сборка запросила запуск — закрываюсь'); quitting = true; cleanup(); app.exit(0); }
    else showWin();
  });
  app.on('before-quit', () => { dlog('before-quit'); cleanup(); });
  app.on('window-all-closed', () => { dlog('window-all-closed'); app.quit(); });
  app.whenReady().then(() => {
    dlog('init');
    app.setAppUserModelId('app.vpnhub.pc');
    S = new Store(app.getPath('userData'));
    createWindow();
    try {
      buddy = BuddyLib.create({
        BrowserWindow, screen, ipcMain, getAware: () => S.d.ui.buddyAware !== false, onChange: () => push(),
        getTitles: async () => (await desktopCapturer.getSources({ types: ['window'], thumbnailSize: { width: 0, height: 0 }, fetchWindowIcons: false })).map((x) => x.name)
      });
    } catch (e) { buddy = null; }
    try {
      tray = new Tray(nativeImage.createFromPath(path.join(__dirname, 'assets', 'tray.png')));
      tray.on('click', showWin);
      updateTray(true);
    } catch (e) { tray = null; }
    applyIcon();
    try { const t = process.env.PORTABLE_EXECUTABLE_FILE; if (t) fs.rmSync(t + '.old', { force: true }); } catch (e) { /* старая копия ещё закрывается */ }
    setTimeout(() => autoUpdateTick(true), 6000);
    setInterval(() => autoUpdateTick(false), 6 * 60 * 60 * 1000);
    if (S.d.ui.autoConnect && S.selectionValid()) startVpn();
  });
}

const lockInfo = { version: FULL_VERSION };

async function takeOver() {
  dlog('takeOver: уже запущена другая копия, жду');
  // 1) пробуем мирно: новая версия просит старую уступить, старая закрывается сама
  for (let i = 0; i < 4; i++) {
    await sleep(1200);
    if (app.requestSingleInstanceLock(lockInfo)) { boot(); return; }
  }
  dlog('takeOver: копия не закрылась, показываю сообщение');
  // 2) старая копия не закрылась (например, совсем старая сборка) — просим закрыть её вручную
  await app.whenReady();
  await dialog.showMessageBox({
    type: 'info', buttons: ['Понятно'], title: 'VPN Hub',
    message: 'VPN Hub уже запущен (значок в трее).',
    detail: 'Если ты только что обновил программу, то это старая версия. Закрой её: правый клик по значку в трее → «Выход» (или Диспетчер задач → VPN Hub → «Снять задачу»), затем запусти программу снова.'
  });
  app.quit();
}

if (app.requestSingleInstanceLock(lockInfo)) boot();
else takeOver();
