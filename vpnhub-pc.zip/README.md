# VPN Hub для Windows

Исходники программы. Собирается автоматически в GitHub Actions: workflow «Build PC» берёт самый свежий
`*.zip` из корня репозитория (внутри должен лежать `package.json`), собирает `VPN-Hub-portable.exe`
и выкладывает его в Artifacts и в релиз `pc-latest` (оттуда программа обновляет себя сама).

Обновление: загрузить новый `vpnhub-pc.zip` в корень репозитория (Add file → Upload files).
Запуск от имени администратора нужен для виртуального адаптера (TUN).
Журнал запуска: `%APPDATA%\VPN Hub\startup.log`.
